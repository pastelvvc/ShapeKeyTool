using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Linq;
using System;

namespace ShapeKeyTools
{
    /// <summary>
    /// シェイプキー永続化エディター
    /// </summary>
    public static class ShapeKeyPersistenceEditor
    {
        /// <summary>
        /// データを保存
        /// </summary>
        public static void SaveData(ShapeKeyPersistence persistence, ShapeKeyToolWindow window)
        {
            if (persistence == null || window == null)
                return;

            var groups = new List<ShapeKeyPersistence.GroupData>();
            var groupFoldouts = new Dictionary<string, bool>();
            var groupTestSliders = new Dictionary<string, float>();
            var lockedShapeKeys = new Dictionary<int, bool>();

            // グループデータを保存
            foreach (var group in window.groupedShapes)
            {
                var groupData = new ShapeKeyPersistence.GroupData
                {
                    groupName = group.Key,
                    shapeKeys = new List<ShapeKeyPersistence.ShapeKeyData>()
                };

                foreach (var shape in group.Value)
                {
                    var shapeData = new ShapeKeyPersistence.ShapeKeyData
                    {
                        name = shape.name,
                        weight = shape.weight,
                        isLocked = shape.isLocked,
                        isExtended = shape.isExtended,
                        originalName = shape.originalName,
                        minValue = shape.minValue,
                        maxValue = shape.maxValue
                    };
                    groupData.shapeKeys.Add(shapeData);
                }

                groups.Add(groupData);
            }

            // グループの展開状態を保存
            foreach (var foldout in window.groupFoldouts)
            {
                groupFoldouts[foldout.Key] = foldout.Value;
            }

            // テストスライダーの値を保存
            foreach (var slider in window.groupTestSliders)
            {
                groupTestSliders[slider.Key] = slider.Value;
            }

            // ロック状態を保存
            foreach (var locked in window.lockedShapeKeys)
            {
                lockedShapeKeys[locked.Key] = locked.Value;
            }

            // データを設定
            persistence.SetGroups(groups);
            persistence.SetGroupFoldouts(groupFoldouts);
            persistence.SetGroupTestSliders(groupTestSliders);
            persistence.SetLockedShapeKeys(lockedShapeKeys);

            // 変更をマーク
            EditorUtility.SetDirty(persistence);
        }

        /// <summary>
        /// データを読み込み（全データ）
        /// </summary>
        public static void LoadData(ShapeKeyPersistence persistence, ShapeKeyToolWindow window)
        {
            LoadDataWithOptions(persistence, window, true, true, true, true, true, true, true, true, true, true, true);
        }

        /// <summary>
        /// 選択的なデータ読み込み（詳細版）
        /// </summary>
        public static void LoadDataWithOptions(ShapeKeyPersistence persistence, ShapeKeyToolWindow window, 
            bool loadGroupStructure, bool loadShapeKeyValues, bool loadLockedStates, bool loadExtendedInfo,
            bool loadFoldouts, bool loadTestSliders, bool loadLockedStatesFromGroups,
            bool loadGroupNames, bool loadShapeKeyNames, bool loadShapeKeyOrder, bool validateMeshCompatibility)
        {
            if (persistence == null || window == null || !persistence.HasData())
                return;

            // 共通の読み込みロジックを使用
            var exportData = ShapeKeyTools.Serialization.CreateExportData();
            exportData.groups = persistence.GetGroups();
            exportData.groupFoldouts = persistence.GetGroupFoldouts();
            exportData.groupTestSliders = persistence.GetGroupTestSliders();
            exportData.lockedShapeKeys = persistence.GetLockedShapeKeys();

            Serialization.ApplyExportDataToStateWithOptions(window, exportData, 
                loadGroupStructure, loadShapeKeyValues, loadLockedStates, loadExtendedInfo,
                loadFoldouts, loadTestSliders, loadLockedStatesFromGroups,
                loadGroupNames, loadShapeKeyNames, loadShapeKeyOrder, validateMeshCompatibility);

            // TreeViewを更新（念のため明示的に追加）
            TreeViewPart.Reload();
            window.Repaint();
        }

        /// <summary>
        /// 選択的なデータ読み込み（旧版 - 後方互換性のため）
        /// </summary>
        public static void LoadDataWithOptions(ShapeKeyPersistence persistence, ShapeKeyToolWindow window, 
            bool loadGroups, bool loadFoldouts, bool loadTestSliders, bool loadLockedStates)
        {
            // 旧版の呼び出しを新版に変換
            LoadDataWithOptions(persistence, window, 
                loadGroups, loadGroups, loadLockedStates, loadGroups, 
                loadFoldouts, loadTestSliders, loadGroups,
                loadGroups, loadGroups, loadGroups, loadGroups);
        }
    }
} 